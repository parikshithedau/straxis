//
//  Test1ViewController.swift
//  Practical
//
//  Created by Parikshit Hedau on 21/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import UIKit

class Test1ViewController: UIViewController {

    @IBOutlet weak var lblInput: UILabel!
    @IBOutlet weak var lblOutput: UILabel!
    
    @IBOutlet weak var container: UIView!
    
    let arrLines = [3,3,3,5,4,5,1]
    
    var nextIndex = 0
    var arrPoints = [CGRect?]()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lblInput.text = "[\((arrLines as NSArray).componentsJoined(by: ","))]"
        
        findOutput()
    }

    //MARK :- Utility Methods
    func findOutput() {

        var startingPointX:CGFloat = 0.0
        var startingPointY:CGFloat = 0.0
        var index = 0
        
        let multiplier : CGFloat = 20.0
        
        for i in 0..<arrLines.count {
            
            let steps = CGFloat(arrLines[i])
            
            var rect = CGRect.zero
            
            var p1 = CGPoint.zero
            var p2 = CGPoint.zero
            
            if index == 0
            {
                p1 = CGPoint(x: startingPointX, y: startingPointY)
                startingPointX = startingPointX + steps
                p2 = CGPoint(x: startingPointX, y: startingPointY)
            }
            else if index == 1 {
                
                p1 = CGPoint(x: startingPointX, y: startingPointY)
                startingPointY = startingPointY + steps
                p2 = CGPoint(x: startingPointX, y: startingPointY)
            }
            else if index == 2
            {
                p1 = CGPoint(x: startingPointX, y: startingPointY)
                startingPointX = startingPointX - steps
                p2 = CGPoint(x: startingPointX, y: startingPointY)
                
                let p3 = p1
                p1 = p2
                p2 = p3
            }
            else
            {
                p1 = CGPoint(x: startingPointX, y: startingPointY)
                startingPointY = startingPointY - steps
                p2 = CGPoint(x: startingPointX, y: startingPointY)
                
                let p3 = p1
                p1 = p2
                p2 = p3
            }
            
            var width: CGFloat = 1.0
            var height: CGFloat = 1.0

            if fabs(p2.x - p1.x) > 0
            {
                width = fabs(p2.x - p1.x)
            }
            if fabs(p2.y - p1.y) > 0
            {
                height = fabs(p2.y - p1.y)
            }
            
            rect = CGRect(x: p1.x * multiplier, y: p1.y * multiplier, width: width * multiplier, height: height * multiplier)
            
            for r in arrPoints {
                
                if (r?.intersects(rect))! {
                    
                    if r?.origin.x != rect.origin.x && r?.origin.y != rect.origin.y {
                        
                        lblOutput.text = "Index \(i), Value \(Int(steps))"
                        return
                    }
                    else if rect.origin.x == r!.origin.x && rect.origin.y != r!.origin.y {
                        
                        if rect.origin.y > r!.origin.y {
                            
                            if r!.size.height >= r!.size.width && rect.size.height >= rect.size.width
                            {
                                lblOutput.text = "Index \(i), Value \(Int(steps))"
                                return
                            }
                        }
                        else
                        {
                            if r!.size.width >= r!.size.height && rect.size.width >= rect.size.height {

                                lblOutput.text = "Index \(i), Value \(Int(steps))"
                                return
                            }
                            else
                            {
                                if r!.size.height >= r!.size.width && rect.size.height >= rect.size.width {
                                
                                    let xDist = (rect.origin.x - r!.origin.x);
                                    let yDist = (rect.origin.y - r!.origin.y);
                                    let distance = sqrt((xDist * xDist) + (yDist * yDist));
                                    
                                    if distance < rect.size.height {
                                        
                                        lblOutput.text = "Index \(i), Value \(Int(steps))"
                                        return
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        if r!.size.width >= r!.size.height && rect.size.width >= rect.size.height {
                            
                            lblOutput.text = "Index \(i), Value \(Int(steps))"
                            return
                        }
                    }
                }
            }
            
            arrPoints.append(rect)
            
            index = index + 1
            
            if index > 3 {
                
                index = 0
            }
        }
    }
    
    @IBAction func nextClicked() {
        
        if let rect = arrPoints[nextIndex] {
            
            let r = CGFloat(arc4random_uniform(255))
            let g = CGFloat(arc4random_uniform(255))
            let b = CGFloat(arc4random_uniform(255))
            
            let view = UIView(frame: rect)
            view.backgroundColor = UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: 1.0)
            container.addSubview(view)
        }
        
        nextIndex = nextIndex + 1
    }
    
    //MARK :-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
