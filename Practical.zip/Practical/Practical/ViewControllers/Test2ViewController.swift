//
//  Test2ViewController.swift
//  Practical
//
//  Created by Parikshit Hedau on 21/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import UIKit

class Test2ViewController: UIViewController {

    @IBOutlet weak var txtInput: UITextField!
    @IBOutlet weak var lblOutput: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //MARK :- Utility Methods
    @objc func showOutput(_ str: String) {
        
        if str.isEmpty {
            
            lblOutput.text = "-"
        }
        else {
            
            var dictChars = [Int:[String]]()
            
            let characters = Array(str)
            
            var max = 0
            
            for ch in characters {
                
                let strCh = String(ch)
                
                let arr = (str as NSString).components(separatedBy: strCh)
                
                if (arr.count-1) > max {
                    
                    max = (arr.count-1)
                    
                    dictChars[max] = [String(ch)]
                }
                else if (arr.count-1) == max {
                    
                    var arrChars = dictChars[max]
                    
                    if !(arrChars?.contains(strCh))! {
                        
                        arrChars?.append(strCh)
                        
                        dictChars[max] = arrChars
                    }
                }
            }
            
            let arrChars = dictChars[max]
            
            let strOutput = (arrChars! as NSArray).componentsJoined(by: "-")
            
            lblOutput.text = strOutput
        }
    }
    
    //MARK :-
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//MARK :- Textfield Delegate Methods
extension Test2ViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var str = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        lblOutput.text = "Loading..."
        
        str = (str as NSString).replacingOccurrences(of: " ", with: "")
        
        perform(#selector(showOutput(_:)), with: str.lowercased(), afterDelay: 0.2)
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }
}
