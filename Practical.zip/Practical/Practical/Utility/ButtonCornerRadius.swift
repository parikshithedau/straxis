//
//  ButtonCornerRadius.swift
//  Practical
//
//  Created by Parikshit Hedau on 21/07/18.
//  Copyright © 2018 parikshit.hedau. All rights reserved.
//

import UIKit

class ButtonCornerRadius: UIButton {

    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        self.layer.cornerRadius = 4.0
        self.layer.masksToBounds = true
    }

}
